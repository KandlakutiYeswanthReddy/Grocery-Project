import { HttpClient, HttpHeaders } from '@angular/common/http';
import { User } from './model/User';
import { environment } from '../environments/environment';
import { Injectable } from '@angular/core';

const httpOptions = {
  headers: new HttpHeaders({
    'Authorization': 'someToken'
  }),
  withCredentials: true
};

@Injectable({
  providedIn: 'root'
})
export class AuthenticateService {

  loginStatus: boolean
  userStatus:boolean
  adminStatus: boolean
  currentUser: User

  constructor(public http: HttpClient) {
    this.loginStatus = false
    this.adminStatus = false
    this.userStatus=false
  }

  signIn(user: User) {
    return this.http.post('http://172.18.218.134:'+environment.port+'/grocery/signin', user, httpOptions)
  }

  signUp(user: User) {
    return this.http.post('http://172.18.218.134:'+environment.port+'/grocery/signup', user, httpOptions)
  }

  signOut() {
    return this.http.post('http://172.18.218.134:'+environment.port+'/grocery/signout', {}, httpOptions)
  }

}