import { Component, OnInit } from '@angular/core';
import { ProductService } from './../product.service';
import { Product } from './../model/Product';
@Component({
  selector: 'app-viewproduct',
  templateUrl: './viewproduct.component.html',
  styleUrls: ['./viewproduct.component.css']
})

export class ViewproductComponent implements OnInit {
  no: number
  myColor: string
 
  constructor(public prodService: ProductService) {

    this.no = 0
    console.log(prodService.productcat)
  
     this.myColor = 'text-primary'
   }

   increase() {
    this.no++
    
    
  }

  decrease() {
    if(this.no>0)

    this.no--
     
  }


  ngOnInit() {
  }
  

}
